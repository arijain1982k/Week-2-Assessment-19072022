import scala.io.StdIn._

object ans6
{
	def main(args: Array[String])
	{
		val inp = readLine("What is your favorite movie of all times? ")
		println(s"$inp is totally awesome!")
	}
}
