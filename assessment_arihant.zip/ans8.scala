object ans8
{
	def main(args: Array[String])
	{
		val list = List.range(100, 150, 10)
		val list_str = list.mkString(", ")
		println(s"Elements of List from 100 to 150, excluding the 150 number literal = $list_str")
		println(s"Sum for elements in the List = ${list.sum}")
	}
}