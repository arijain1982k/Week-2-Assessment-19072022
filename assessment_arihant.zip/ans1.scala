object ans1
{
	def main(args: Array[String])
	{
		val input_str = "https://www.google.com"
		val result = input_str.reverse.toUpperCase()
		println(result)
	}
}