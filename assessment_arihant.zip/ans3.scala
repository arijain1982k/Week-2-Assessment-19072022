import scala.io.StdIn._

object ans3
{
	def main(args: Array[String])
	{
			val name = readLine("Enter your name: ")
			print("Enter your age: ")
			val age = readInt()
			println(Console.BOLD)
			print("Name: ")
			print(Console.UNDERLINED)
			print(name)
			println(Console.BOLD)
			print("Age: ")
			print(Console.RESET)
			print(age)
	}
}