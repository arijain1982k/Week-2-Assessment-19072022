object ans5
{
	def main(args: Array[String])
	{
		val item = "Glazed Donut"
		val cost = 2.50
		val num = 10
		val total = num * cost
		println(f"""Total cost of $num $item${if (num > 1) "s" else ""} = $$$total%1.2f""")
	}
}