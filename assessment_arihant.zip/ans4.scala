object ans4
{
	def main(args: Array[String])
	{
		val str = "http://google.com"
		val char8 = str.charAt(7)
		println(s"The 8th character literal in $str = $char8")
	}	
}